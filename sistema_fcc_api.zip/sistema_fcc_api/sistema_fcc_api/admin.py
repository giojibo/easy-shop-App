from django.contrib import admin
from sistema_fcc_api.models import *

admin.site.register(Administradores)
admin.site.register(Clientes)
admin.site.register(Vendedores)
admin.site.register(Productos)